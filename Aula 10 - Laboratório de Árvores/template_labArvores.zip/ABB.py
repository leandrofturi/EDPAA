class ABB:
    
    def __init__ (self, raiz):
        # cria uma nova ABB com o info raiz e sem filhos
        self._info = raiz
        self._eprox = None
        self._dprox = None
    

# Procura elemento com info igual a v na ABB h
# Versão recursiva
def busca(h, v):
    pass

# conta elementos com info igual a v na ABB h
def conta(h, v):
    pass

# altura de uma ABB - raíz é altura 0
def altura(h):
    pass
    
def ImprimeABBinOrder(h):
    pass

def ImprimeABBpreOrder(h):
    pass

def ImprimeABBpostOrder(h):
    pass

def ImprimeABBinLevel(h):
    pass

def insereElementoABB(h, elemento):
    pass

# Monta uma ABB a partir de uma lista 
# Elementos repetidos devem ficar a direita
def montaABB(a, a_len):
    pass

'''       
Testes

lista = [0, 1, 2, 3, 4, 5, 6]
outralista = [10, 4, 2, 30, 7, 15, 40, 27, 60, 6]
mabb = montaABB(lista, len(lista))
moabb = montaABB(outralista, len(outralista))

ImprimeABBinOrder(mabb)
print()
ImprimeABBinOrder(moabb)
print()

ImprimeABBpreOrder(mabb)
print()
ImprimeABBpreOrder(moabb)
print()

ImprimeABBpostOrder(mabb)
print()
ImprimeABBpostOrder(moabb)
print()

ImprimeABBinLevel(mabb)
print()
ImprimeABBinLevel(moabb)
print()
'''

